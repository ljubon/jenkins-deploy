# webapp-aws-terraform
Simple WebApp environment with Web and DB server deployed on AWS with Terraform.

* Infrastructure setup:   Terraform
* Server provisioning:    Ansible

